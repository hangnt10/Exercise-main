import Utilities.*;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Iterator;


public class Main {

    public static void main(String[] args) throws Exception {
        Client client1 = new Client("Client1");
        client1.login("1300");
        client1.enterGiftCode_directly("a140efd0"); // chọn trực tiếp icon GiftCode tại màn hình lobby
//        client1.enterGiftCode_settings("6112eaf1"); // chọn GiftCode tại màn hình Settings
    }
}

